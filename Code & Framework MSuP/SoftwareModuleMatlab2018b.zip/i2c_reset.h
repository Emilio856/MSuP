#ifndef I2C_RESET_H
#define I2C_RESET_H

void init_i2c( void );

void reset_i2c( void );

#endif
